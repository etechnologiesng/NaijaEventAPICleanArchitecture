﻿using NaijaEvent.Application.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace NaijaEvent.Application.Event.Command.CreateEvent
{
    class CreateEventCommandHandler
    {
        //private async Task<RequestResult> HandleCreateEvent(CreateEventCommand request, CancellationToken cancellationToken)
        //{

        //    try
        //    {
        //        var article = _mapper.Map<Article>(request);
        //        var newArticle = await _articleManagementService.CreateArticleAndHistory(article);

        //        return CommandResult.Success(newArticle.Slug);
        //    }
        //    catch (Exception ex)
        //    {
        //        return CommandResult.Error(new CreateArticleException("There was an error creating the article", ex));
        //    }

        }
}
