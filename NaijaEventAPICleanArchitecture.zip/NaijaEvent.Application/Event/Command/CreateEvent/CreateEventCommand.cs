﻿using MediatR;
using System;

namespace NaijaEvent.Application
{
    public class CreateEventCommand : IRequest
    {
        public string EventId { get; set; }
        public string EventName { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }


        public class Handler : IRequestHandler<CreateCustomerCommand, Unit>
        {
            private readonly INorthwindDbContext _context;
            private readonly IMediator _mediator;

            public Handler(INorthwindDbContext context, IMediator mediator)
            {
                _context = context;
                _mediator = mediator;
            }

           

                await _mediator.Publish(new CustomerCreated { CustomerId = entity.CustomerId }, cancellationToken);

                return Unit.Value;
            }
        }
    }
}
