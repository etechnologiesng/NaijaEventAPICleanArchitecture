﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using NaijaEvent;
using NaijaEvent.Domain;

namespace NaijaEvent.Application.Interfaces
{
   public  interface INEventRepository : IRepository<NEvent>
    {

      

    }
}
