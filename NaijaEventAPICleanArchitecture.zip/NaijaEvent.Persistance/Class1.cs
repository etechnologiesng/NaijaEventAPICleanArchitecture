﻿using System;

namespace NaijaEvent.Persistance
{
    public class Class1
    {
    }
}
